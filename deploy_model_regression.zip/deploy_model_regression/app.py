import numpy as np
import pandas as pd
from flask import Flask, request, jsonify, render_template
import joblib
import pickle

# Create flask app
app = Flask(__name__)
model = pickle.load(open('model(1).pkl', 'rb'))

@app.route("/")
def Home():
    return render_template("index.html")

@app.route("/predict", methods = ["POST"])
def predict():
    float_features = [float(x) for x in request.form.values()]
    features = [np.array(float_features)]
    prediction = model.predict(features)
    return render_template("index.html", prediction_text = "La prédiction de vente est {} : ".format(np.round(prediction[0],1)))
  
if __name__ == "__main__":
    app.run(debug=True)